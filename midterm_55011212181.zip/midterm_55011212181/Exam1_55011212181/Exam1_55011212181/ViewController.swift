//
//  ViewController.swift
//  Exam1_55011212181
//
//  Created by Student on 10/10/2557 BE.
//  Copyright (c) 2557 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    var ans:Double!
    var ans1:Double!
    var ans2:Double!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var volumeLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var volumeTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    
    @IBOutlet weak var totalBT: UIButton!
    @IBAction func totalButton(sender: AnyObject) {
        volumeTF.resignFirstResponder()
        
        ans1 = Double((volumeTF.text as NSString).doubleValue)
        ans2 = Double((priceTF.text as NSString).doubleValue)
        ans = ans1 * ans2;
            totalTF.text = String(format:"%0.2f" ,ans)
        
    }
    
    @IBOutlet weak var totalTF: UITextField!
    @IBOutlet weak var profitBT: UIButton!
    @IBAction func profitButton(sender: AnyObject) {
        
    }
    @IBOutlet weak var tableV: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    
}

