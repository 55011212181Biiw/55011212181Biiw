//
//  ViewController.swift
//  Exam1_55011212181
//
//  Created by Student on 12/17/2557 BE.
//  Copyright (c) 2557 Student. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController{

    var items = [NSManagedObject]()
    
    @IBOutlet weak var tableView: UITableView!

    @IBAction func add(sender: AnyObject) {
   

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}

